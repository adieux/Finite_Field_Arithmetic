#include <stdio.h>

#include <math.h>
#include "galois.h"
#include "galois.c"



main()
{

	int b = 29; // byte size
	int i = 0;
	int k = 0;

	int y = 32;
	int y_guess = 96;

	int x1 = 194;
	int x2 = 110;
	int x1_guess = 194;
	int x2_guess = 110;

	int e1 = 218;
	int e2 = 0;

	int yx1x2 = 0;
	int yx1x2_cube = 0;
	int yx1x2_sqrt = 0;

	int Robust_left = 0;
	int Robust_right = 0;

	int Robust_fail = 0;

	// Robust check
/*
	yx1x2 = y ^ x1 ^ x2;
	yx1x2_sqrt = galois_single_multiply(yx1x2, yx1x2, b);
	yx1x2_cube = galois_single_multiply(yx1x2, yx1x2_sqrt, b);

	Robust_left = galois_single_multiply(galois_single_multiply(yx1x2, (yx1x2 ^ e1), b), e1, b);
	Robust_right = e2 ^ galois_single_multiply(e1, galois_single_multiply(e1, e1, b), b);

	Robust_fail = (Robust_left == Robust_right) ? 1 : 0;
	*/

	y = galois_single_multiply(7, 11, b);

	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	printf("y is: %d\n", y);

	printf ("\nRobust_left = %d", Robust_left);
	printf ("\nRobust_right = %d", Robust_right);


	// just for trying
	int y1 = 0;
	int y2 = 0;
	int y3 = 0;
	int y4 = 0;

	y1 = galois_single_multiply(2, 3, 8);
	y2 = galois_single_multiply(2, 1, 8);
	y3 = galois_single_multiply(3, 3, 8);
	y4 = galois_single_multiply(4, 3, 8);

	printf("\n\n\n\nGF(2^8): %d, %d, %d, %d", y1, y2, y3, y4);
	printf("\n\n\n\nGF(2^8): %d", y1^y2^y3^y4);
	printf("\n\n\n\n");

}